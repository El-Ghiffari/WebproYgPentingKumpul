<?php

class rolemodel extends CI_Model {
	public function getProducts() {
		return $this->db->get('products')->result();
	}
	public function getContact() {
		return $this->db->get('contact')->result();
	}

	public function addContacts($data)
	{
		return $this->db->insert('contact', $data);
	}

	public function removeContact($id)
	{
		$this->db->where('id', $id);
		return $this->db->delete('contact');
	}

	public function removeProducts($id)
	{
		$this->db->where('id_pro', $id);
		return $this->db->delete('products');
	}

	public function addProducts($data)
	{
		return $this->db->insert('products', $data);
	}

	public function updateProducts($id, $data)
	{
		$this->db->where('id_pro', $id);
		return $this->db->update('products', $data);
	}
}