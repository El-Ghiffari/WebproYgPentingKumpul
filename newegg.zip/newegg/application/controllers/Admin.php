<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    
    public function __construct()
	{
		parent::__construct();
		$this->load->model('rolemodel');
		$this->load->model('loginmodel');
		$this->load->helper(array('form', 'url'));
	}

	function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('index.php/home'));
	}

	public function index()
	{
		$data['products'] = $this->rolemodel->getProducts();
		$this->load->view('halamanadmin',$data);
	}

	public function add()
	{
		$this->load->view('add', array('error' => ' ' ));
	}

	public function edit($id)
	{
		$this->load->view('edit', $id);
	}

	public function addContacts()
	{
		$data = [
			"fname" => $this->input->post('fname', true),
			"lname" => $this->input->post('lname', true),
			"email" => $this->input->post('email', true),
			"subject" => $this->input->post('subject', true),
			"message" => $this->input->post('message', true),
		];

		$this->rolemodel->addContacts($data);
		$this->session->set_flashdata('flash', 'Message has been sent!');
		redirect('halamanadmin','refresh');
	}


	public function uploadImage()
	{
	    $config['upload_path'] 		= './assets/image/';
	    $config['allowed_types']    = 'gif|jpg|png';
	    $config['max_size']         = 5024;

	    $this->load->library('upload', $config);

	    if ($this->upload->do_upload('userfile')) {
			$data = array('upload_data' => $this->upload->data());
		} else {
			$error = array('error' => $this->upload->display_errors());
		}
	}

	public function manageProducts()
	{
		$data['products'] = $this->rolemodel->getProducts();
		$this->load->view('halamanadmin',$data);
	}

	public function removeProducts($id)
	{
		$this->rolemodel->removeProducts($id);
		$data['products'] = $this->rolemodel->getProducts();
		$this->load->view('halamanadmin',$data);
		//redirect('halamanadmin','refresh');
	}

	public function addProducts()
	{
		$data = [
			'id_pro' => $this->input->post('id_pro'),
			'name_pro' => $this->input->post('name_pro'),
			'price' => $this->input->post('price'),
			'description' => $this->input->post('description'),
			'photo' => ''
		];
		$this->uploadImage();
		$file_info = $this->upload->data();
		$data['photo'] = $file_info['file_name'];
		$this->rolemodel->addProducts($data);
		$this->session->set_flashdata('alert', 'Product has been added!');
		$data['products'] = $this->rolemodel->getProducts();
		$this->load->view('halamanadmin',$data);
	}

	public function editProducts($id)
	{
		$data = [
			'id_pro' => $this->input->post('id_pro'),
			'name_pro' => $this->input->post('name_pro'),
			'price' => $this->input->post('price'),
			'description' => $this->input->post('description'),
			'photo' => ''
		];
		$this->uploadImage();
		$file_info = $this->upload->data();
		$data['photo'] = $file_info['file_name'];
		$this->rolemodel->updateProducts($id,$data);
		$this->session->set_flashdata('alert', 'Product has been updated!');
		$data['products'] = $this->rolemodel->getProducts();
		$this->load->view('halamanadmin',$data);
	}

}
