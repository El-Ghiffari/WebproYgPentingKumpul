<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    
    public function __construct()
	{
		parent::__construct();
		$this->load->model('rolemodel');
		$this->load->model('loginmodel');
	}

	public function login()
	{
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $where = array(
			'username' => $username,
			'password' => $password
		);
		$check = $this->loginmodel->checkLogin("admin",$where)->num_rows();
		if ($check > 0) {
			$data_session = array(
				'name' => $username,
				'status' => "login"
				);
 
			$this->session->set_userdata($data_session);
 			redirect(base_url('admin'));
 
		} else {
			$this->session->set_flashdata('flash', 'Wrong Username or Password!');
			redirect(base_url("home"));
		}
	}

	// public function products()
	// {
	// 	$data['products'] = $this->rolemodel->getProducts();
	// 	$this->load->view('HomePage',$data);
	// }

	public function index()
	{
		$data['products'] = $this->rolemodel->getProducts();
		$this->load->view('HomePage',$data);
	}

	public function about()
	{
		$this->load->view('AboutView');
	}

	public function contacts()
	{
		$this->load->view('ContactView');
	}

	public function loginpage()
	{
		$this->load->view('loginPage');
	}

	public function addContacts()
	{
		$data = [
			"name" => $this->input->post('name', true),
			"email" => $this->input->post('email', true),
			"message" => $this->input->post('message', true),
		];

		$this->rolemodel->addContacts($data);
		$this->session->set_flashdata('alert', 'Message has been sent!');
		redirect('home/contacts','refresh');
	}
}
