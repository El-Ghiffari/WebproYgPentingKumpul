<html>
    <head>
    <title>Login - Newegg</title>
    <style>
	html{
        background-color: #fff;
 		background-size: cover;
 		font-family: arial;
 		text-align: center;
	} 
	.login_1303181077{
		margin: 250px auto;
        	width: 300px;
        	padding: 10px;
       		font-size: 16px;
        	border-radius: 5px ;
        	background: white;
	}
 	input[type=text], input[type=password] {
        	margin: 3px;
        	width: 250px;
        	padding: 10px;
        	border-style: none;
        	border-bottom-style: solid;
        	border-bottom-color: #ddd;

	}
	input[type=text]:hover, input[type=password]:hover {
   		outline: none;
   	border-style: none;
   	border-bottom-style: solid;
   	border-bottom-color: #0040FF;        
	}

	input[type=text]:focus, input[type=password]:focus{
		border-bottom-style: solid;
		background-color:  #ffd600;
	}
	button{
        	margin 16px auto;
        	float: center;
        	padding: 5px;
        	height: 40px;
        	width: 60px;
        	border: 1px solid #fff;
        	background: #ffd600;
        	cursor: pointer;
        	border-radius: 5px ;
	}

	button:hover{
		background: #0040FF;
		
	}
    </style>
    </head>
    <body>
        <div class="login">
            <img style="height: 100px" src="http://localhost/newegg/assets/image/logo.png">
            <h2 class="footer-heading">Login</h2>
            <form method="POST" action="<?php echo base_url('home/login') ?>" class="form-consultation">
              <div class="form-group">
                <input type="text" name="username" class="form-control" placeholder="Username" required>
              </div>
              <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
              </div>
              <div class="form-group">
                <button type="submit" class="form-control submit px-3">Login</button>
              </div>
            </form>
        </div>
    </body>
</html>