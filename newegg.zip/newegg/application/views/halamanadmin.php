<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
  	<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

</head>

<body>

	<nav class="navbar navbar-red navbar-fixed-top">
  	<div class="container">
    	<div class="navbar-header">
       	  <a class="navbar-brand" href="<?php echo base_url('Home');?>">Home</a> 
    	</div>
    	<ul class="nav navbar-nav navbar-right text-center">
        <li class="nav-item dropdown">
         <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" onclick="return confirm('Kembali ke menu Utama?')" href="<?php echo base_url('Home');?>">Logout</a></li>
          </ul>
        </li>
      </ul>  
 	  </div>
	</nav>


	<section class="site-section">
      <div class="container">
          <div class="row justify-content-center pb-5 mb-3">
            <div class="col-md-7 heading-section text-center">
              <h1> Products List </h1>
              <span class="subheading">MANAGE PRODUCTS</span>
          </div>
      </div>

     <table class="table">
        <thead class="thead-dark">
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Name</th>
          <th scope="col">Price</th>
          <th scope="col">Photo</th>
          <th scope="col">Picture</th>
          <th scope="col" colspan="2">Action</th>
        </tr>
        </thead>
        <?php $num = 0; ?>
        <?php foreach ($products as $row): ?>
        <?php $num = $num+1; ?>
        <tbody>
        <tr>
          <th scope="row"><?= $num ?></th>
          <td><?= $row->name_pro ?></td>
          <td><?= $row->price ?></td>
          <td><?= $row->description ?></td>
          <td><?= $row->photo ?></td>
          <td width="20px"><a href="<?php echo base_url(); ?>admin/edit/<?= $row->id_pro ?>"><input type="submit" value="Edit" class="btn btn-info"></td>
          <td width="20px"><a href="<?php echo base_url(); ?>admin/removeProducts/<?= $row->id_pro ?>"><input type="submit" value="Delete" class="btn btn-danger"></a></td>
        </tr>
        </tbody>
        <?php endforeach ?>
        <tbody>
          <td colspan="8" align="right"> <a href="<?php echo base_url('admin/add'); ?>"><input type="submit" value="Add" class="btn btn-primary"></a></td>
        </tbody>
    </table> 
    </div>
  </section>



<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"></script> 
</body>
 <script type="text/javascript">
    $(document).ready( function () {
        $('#table').DataTable();
    } );
  </script>
</html>