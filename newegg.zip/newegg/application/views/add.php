<!DOCTYPE html>
<html>
<head>
	<title>Add</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
  	<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

</head>
<body>
	<nav class="navbar navbar-red navbar-fixed-top">
  	<div class="container">
    	<div class="navbar-header">
       	  <a class="navbar-brand" href="<?php echo base_url('Home');?>">Home</a> 
    	</div>
    	<ul class="nav navbar-nav navbar-right text-center">
        <li class="nav-item dropdown">
         <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" onclick="return confirm('Kembali ke menu Utama?')" href="<?php echo base_url('Home');?>">Logout</a></li>
          </ul>
        </li>
      </ul>  
 	  </div>
	</nav>

	 <section class="site-section">
      <div class="container">
          <div class="row justify-content-center pb-5 mb-3">
            <div class="col-md-7 heading-section text-center">
              <h1> Add Products </h1>
              <span class="subheading">FILL DATA CORRESPONDINGLY</span>
          </div>
      </div>

       <form method="POST" action="<?php echo base_url('admin/addProducts') ?>" enctype="multipart/form-data">
        <div class="form-group">
          <label>ID Product</label>
          <input type="text" name="id_pro" class="form-control" id="id_pro">
        </div>
        <div class="form-group">
          <label>Name</label>
          <input type="text" name="name_pro" class="form-control" id="name_pro">
        </div>
        <div class="form-group">
          <label>Price</label>
          <input type="text" name="price" class="form-control" id="price">
        </div>
        <div class="form-group">
          <label>Description</label>
          <input type="text" name="description" class="form-control" id="description">
        </div>
        <div class="form-group">
          <label>Image</label>
          <input type='file' name="userfile" id="userfile">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>

    </div>
  </section>
       <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <input  type="submit" class="btn btn-primary" id="hapus" value="Submit" placeholder="Simpan"> -->
      </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"></script> 
</body>
 <script type="text/javascript">
    $(document).ready( function () {
        $('#table').DataTable();
    } );
  </script>
</html>